package nemesis.top.client.gui.hud

import nemesis.top.client.module.ModuleManager
import nemesis.top.client.render.FontRenderer
import nemesis.top.client.util.AnimationUtil
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.GuiGraphicsExtractor
import org.lwjgl.glfw.GLFW

private const val KEYBINDS_WIDTH = 126.0f
private const val KEYBIND_INDICATOR_RIGHT_INSET = 12.0f
private const val KEYBIND_ROW_HEIGHT = 17.0f
private const val KEYBIND_MODULE_TEXT_SIZE = 10.0f
private const val KEYBIND_BIND_TEXT_SIZE = 10.0f
private const val ROW_ENTER_ANIMATION_DURATION = 260L
private const val ROW_EXIT_ANIMATION_DURATION = 320L

class KeybindsHudWidget : HudWidget(
    id = "keybinds",
    title = "Keybinds",
    iconGlyph = "A",
    x = 7.5f,
    y = 28.0f,
    width = KEYBINDS_WIDTH,
    height = 48.0f,
) {
    private val rowAnimations = linkedMapOf<String, RowState>()
    private var renderRows = emptyList<RowState>()

    override fun visible(mc: Minecraft, preview: Boolean): Boolean {
        return enabled && activeRows(false).isNotEmpty()
    }

    override fun update(mc: Minecraft, preview: Boolean) {
        renderRows = collectRows(activeRows(preview))
        val rows = renderRows
        val animatedRows = rows.sumOf { it.animation.value.coerceAtLeast(0.0f).toDouble() }.toFloat()
        bounds.height = 31.0f + animatedRows * KEYBIND_ROW_HEIGHT
        val contentWidth = rows.maxOfOrNull {
            FontRenderer.width(FontRenderer.Face.SfRegular, it.name, KEYBIND_MODULE_TEXT_SIZE) +
                FontRenderer.width(FontRenderer.Face.SfSemibold, it.bind, KEYBIND_BIND_TEXT_SIZE) + 38.0f
        } ?: 0.0f
        bounds.width = maxOf(KEYBINDS_WIDTH, contentWidth)
    }

    override fun render(graphics: GuiGraphicsExtractor, mc: Minecraft, preview: Boolean) {
        val rows = renderRows
        if (rows.isEmpty()) return

        HudStyle.panel(graphics, bounds)
        FontRenderer.draw(graphics, FontRenderer.Face.SfMedium, "Binds", bounds.x + 9.0f, bounds.y + 8.0f, 10.0f, HudStyle.TEXT)
        HudStyle.icon(graphics, iconGlyph, bounds.x + bounds.width - 20.0f, bounds.y + 7.0f, 10.0f)
        var rowOffset = 0.0f
        rows.forEachIndexed { index, row ->
            val rowProgress = row.animation.value.coerceIn(0.0f, 1.0f)
            if (rowProgress <= 0.01f) return@forEachIndexed
            val rowY = bounds.y + 29.0f + index * 17.0f
            val animatedRowY = bounds.y + 29.0f + rowOffset
            val rowScale = (0.9f + minOf(rowProgress, 1.12f) * 0.1f).coerceIn(0.9f, 1.035f)
            val rowPivotX = bounds.x + bounds.width * 0.5f
            val rowPivotY = animatedRowY + 6.5f
            val color = fadeColor(HudStyle.TEXT, rowProgress)
            val accent = fadeColor(HudStyle.ACCENT, rowProgress)

            graphics.pose().pushMatrix()
            graphics.pose().translate(rowPivotX, rowPivotY)
            graphics.pose().scale(rowScale, rowScale)
            graphics.pose().translate(-rowPivotX, -rowPivotY)
            FontRenderer.draw(graphics, FontRenderer.Face.SfRegular, row.name, bounds.x + 10.0f, animatedRowY, KEYBIND_MODULE_TEXT_SIZE, color)
            val bindWidth = FontRenderer.width(FontRenderer.Face.SfSemibold, row.bind, KEYBIND_BIND_TEXT_SIZE)
            FontRenderer.draw(
                graphics,
                FontRenderer.Face.SfSemibold,
                row.bind,
                bounds.x + bounds.width - bindWidth - KEYBIND_INDICATOR_RIGHT_INSET,
                animatedRowY + 0.5f,
                KEYBIND_BIND_TEXT_SIZE,
                accent,
            )
            graphics.pose().popMatrix()
            rowOffset += KEYBIND_ROW_HEIGHT * rowProgress
        }
    }

    private fun activeRows(preview: Boolean): List<BindRow> {
        if (!enabled && !preview) return emptyList()
        val active = ModuleManager.modules
            .filter { it.bind >= 0 && it.enabled }
            .sortedBy { it.name.lowercase() }
            .map { BindRow(it.name, keyName(it.bind)) }
        if (active.isNotEmpty() || !preview) return active
        return emptyList()
    }

    private fun collectRows(activeRows: List<BindRow>): List<RowState> {
        val activeRowsByName = activeRows.associateBy { it.name }
        activeRows.forEach { row ->
            val state = rowAnimations.computeIfAbsent(row.name) { RowState(row.name, row.bind) }
            state.bind = row.bind
        }

        val rows = mutableListOf<RowState>()
        val iterator = rowAnimations.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            val row = entry.value
            val active = activeRowsByName.containsKey(row.name)
            row.animation.update()
            row.animation.run(if (active) 1.0f else 0.0f,
                if (active) ROW_ENTER_ANIMATION_DURATION else ROW_EXIT_ANIMATION_DURATION,
                if (active) AnimationUtil::easeOutSoftBack else AnimationUtil::easeInBack,
                true,
            )
            if (!active && row.animation.value <= 0.01f) iterator.remove()
            else rows += row
        }

        return rows.sortedBy { it.name.lowercase() }
    }

    private fun keyName(key: Int): String {
        return GLFW.glfwGetKeyName(key, 0)?.uppercase() ?: when (key) {
            GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT"
            GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT"
            else -> key.toString()
        }
    }

    private fun fadeColor(color: Int, alphaMultiplier: Float): Int {
        val alpha = ((color ushr 24) * alphaMultiplier.coerceIn(0.0f, 1.0f)).toInt().coerceIn(0, 255)
        return (color and 0x00FFFFFF) or (alpha shl 24)
    }

    private data class BindRow(val name: String, val bind: String)

    private class RowState(
        val name: String,
        var bind: String,
    ) {
        val animation = AnimationUtil.TimedAnimation(0.0f)
    }
}
