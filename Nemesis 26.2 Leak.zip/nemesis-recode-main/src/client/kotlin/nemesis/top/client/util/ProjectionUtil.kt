package nemesis.top.client.util

import com.mojang.math.Axis
import net.minecraft.client.Minecraft
import net.minecraft.client.renderer.state.level.CameraRenderState
import net.minecraft.world.phys.Vec3
import org.joml.Matrix4fc
import org.joml.Quaternionf
import org.joml.Vector2f
import org.joml.Vector3f
import kotlin.math.abs
import kotlin.math.tan

object ProjectionUtil {
    data class Snapshot(
        val cameraPos: Vec3,
        val xRot: Float,
        val yRot: Float,
        val fov: Float,
        val viewportWidth: Float,
        val viewportHeight: Float,
    )

    @Volatile
    private var snapshot: Snapshot? = null

    fun capture(cameraRenderState: CameraRenderState, projectionMatrix: Matrix4fc) {
        val pos = cameraRenderState.pos
        val window = Minecraft.getInstance().window
        val width = window.guiScaledWidth.toFloat()
        val height = window.guiScaledHeight.toFloat()
        if (width <= 0.0f || height <= 0.0f) return

        snapshot = Snapshot(
            pos,
            cameraRenderState.xRot,
            cameraRenderState.yRot,
            cameraRenderState.hudFov,
            width,
            height,
        )
    }

    fun project(vec: Vec3): Vector2f? {
        val state = snapshot ?: return null
        val cameraRotation = Axis.YP.rotationDegrees(-state.yRot)
            .mul(Axis.XP.rotationDegrees(state.xRot), Quaternionf())
        cameraRotation.conjugate()

        val viewPos = Vector3f(
            (state.cameraPos.x - vec.x).toFloat(),
            (state.cameraPos.y - vec.y).toFloat(),
            (state.cameraPos.z - vec.z).toFloat(),
        )
        viewPos.rotate(cameraRotation)

        if (!viewPos.x.isFinite() || !viewPos.y.isFinite() || !viewPos.z.isFinite() || viewPos.z >= -1.0e-4f) {
            return null
        }

        val fov = state.fov.toDouble()
        if (!fov.isFinite() || fov <= 0.0) return null

        val halfWidth = state.viewportWidth * 0.5f
        val halfHeight = state.viewportHeight * 0.5f
        val tanHalfFov = tan(Math.toRadians(fov * 0.5))
        if (!tanHalfFov.isFinite() || abs(tanHalfFov) < 1.0e-4) return null

        val scale = halfHeight / (viewPos.z * tanHalfFov)

        return Vector2f(
            -viewPos.x * scale.toFloat() + halfWidth,
            halfHeight - viewPos.y * scale.toFloat(),
        )
    }
}
