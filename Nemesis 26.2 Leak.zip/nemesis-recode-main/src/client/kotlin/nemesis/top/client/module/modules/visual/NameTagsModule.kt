package nemesis.top.client.module.modules.visual

import nemesis.top.client.module.Module
import nemesis.top.client.module.ModuleCategory
import nemesis.top.client.module.ModuleManager
import nemesis.top.client.module.setting.BooleanSetting
import nemesis.top.client.module.setting.FloatSetting
import nemesis.top.client.gui.NemesisOverlay
import nemesis.top.client.render.FontRenderer
import nemesis.top.client.render.NemesisGuiRenderer
import nemesis.top.client.util.GuiBoxUtil
import nemesis.top.client.util.ProjectionUtil
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.GuiGraphicsExtractor
import net.minecraft.world.entity.LivingEntity
import net.minecraft.world.entity.animal.Animal
import net.minecraft.world.entity.monster.Enemy
import net.minecraft.world.entity.player.Player
import net.minecraft.world.phys.Vec3
import kotlin.math.max
import kotlin.math.roundToInt

class NameTagsModule : Module(
    name = "Name Tags",
    category = ModuleCategory.VISUALS,
    description = "Renders custom nametags for entities",
    enabledByDefault = false,
) {
    private val targets = setting(
        nemesis.top.client.module.setting.MultiBooleanSetting(
            "Targets",
            BooleanSetting("Self", false),
            BooleanSetting("Players", true),
            BooleanSetting("Animals", false),
            BooleanSetting("Mobs", false),
        )
    )
    private val scale = setting(FloatSetting("Scale", 1.0f, 0.5f, 3.0f, 0.1f))
    private val health = setting(BooleanSetting("Health", true))
    private val backgroundAlpha = setting(FloatSetting("Background Alpha", 0.5f, 0.0f, 1.0f, 0.05f))

    companion object {
        private const val TAG_VERTICAL_OFFSET = 8.0f
        private const val TAG_WORLD_HEAD_OFFSET = 0.18f
        private const val TAG_RADIUS = 4.5f

        @Volatile
        private var currentBlurBoxes: List<NemesisOverlay.BlurBox> = emptyList()
    }

    // Called every render frame from GuiMixin
    fun onRenderWithEntities(graphics: GuiGraphicsExtractor, partialTick: Float) {
        val mc = Minecraft.getInstance()
        if (!enabled || mc.level == null || mc.player == null) return

        val scaleVal = scale.value
        val bgAlpha = backgroundAlpha.value
        val showHp = health.value

        val window = mc.window
        val screenW = window.guiScaledWidth.toFloat()
        val screenH = window.guiScaledHeight.toFloat()
        val cameraPos = mc.gameRenderer.mainCamera.position()
        val worldEntities = buildList {
            addAll(mc.level!!.players())
            mc.level!!.entitiesForRendering().forEach { entity ->
                if (entity !is Player) add(entity)
            }
        }

        data class TagEntry(
            val distanceSq: Double,
            val tagX: Float,
            val tagY: Float,
            val tagWidth: Float,
            val tagHeight: Float,
            val textX: Float, val textY: Float,
            val name: String,
            val healthText: String, val hpColor: Int,
            val nameWidth: Float, val fontSize: Float
        )
        val textEntries = mutableListOf<TagEntry>()
        val blurBoxes = mutableListOf<NemesisOverlay.BlurBox>()

        for (entity in worldEntities) {
            if (entity !is LivingEntity) continue
            if (!shouldRenderEntity(entity, mc)) continue

            val xI = entity.xOld + (entity.x - entity.xOld) * partialTick
            val yI = entity.yOld + (entity.y - entity.yOld) * partialTick
            val zI = entity.zOld + (entity.z - entity.zOld) * partialTick
            val worldPos = Vec3(xI, yI + entity.bbHeight + TAG_WORLD_HEAD_OFFSET, zI)

            val headAnchor = ProjectionUtil.project(worldPos) ?: continue

            val distanceSq = worldPos.distanceToSqr(cameraPos)
            val fontSize = 8.0f * scaleVal
            val gap = 2.0f * scaleVal

            val name = entity.name.string
            val healthStr = if (showHp) " ${formatHealth(entity)}" else ""

            val nameWidth = FontRenderer.width(FontRenderer.Face.SfMedium, name, fontSize)
            val healthWidth = FontRenderer.width(FontRenderer.Face.SfMedium, healthStr, fontSize)
            val textWidth = nameWidth + healthWidth
            val tagWidth = textWidth + gap * 2.0f
            val tagHeight = fontSize + gap * 2.0f

            val tagX = headAnchor.x - tagWidth / 2.0f
            val tagY = headAnchor.y - tagHeight - TAG_VERTICAL_OFFSET * scaleVal

            // Cull tags fully outside screen
            if (tagX + tagWidth < 0 || tagX > screenW || tagY + tagHeight < 0 || tagY > screenH) continue

            val textX = tagX + gap
            val textY = tagY + (tagHeight - fontSize) / 2.0f
            textEntries += TagEntry(distanceSq, tagX, tagY, tagWidth, tagHeight, textX, textY, name, healthStr, getHealthColor(entity), nameWidth, fontSize)
            blurBoxes += NemesisOverlay.BlurBox(tagX * window.guiScale, tagY * window.guiScale, tagWidth * window.guiScale, tagHeight * window.guiScale, TAG_RADIUS * scaleVal * window.guiScale, bgAlpha)
        }

        currentBlurBoxes = blurBoxes

        for (entry in textEntries.sortedByDescending { it.distanceSq }) {
            if (!ModuleManager.postProcessing.enabled) {
                val boxes = mutableListOf<GuiBoxUtil.Box>()
                val bgColor = NemesisGuiRenderer.alpha(0x000000, bgAlpha)
                NemesisGuiRenderer.rect(boxes, entry.tagX, entry.tagY, entry.tagWidth, entry.tagHeight, TAG_RADIUS * scaleVal, bgColor)
                boxes.forEach { GuiBoxUtil.draw(graphics, it) }
            }

            FontRenderer.draw(graphics, FontRenderer.Face.SfMedium, entry.name, entry.textX, entry.textY, entry.fontSize, 0xFFFFFFFF.toInt())
            if (showHp && entry.healthText.isNotEmpty()) {
                FontRenderer.draw(graphics, FontRenderer.Face.SfMedium, entry.healthText, entry.textX + entry.nameWidth, entry.textY, entry.fontSize, entry.hpColor)
            }
        }

    }

    fun blurBoxes(guiScale: Float): List<NemesisOverlay.BlurBox> {
        if (!enabled || !ModuleManager.postProcessing.enabled) return emptyList()
        return currentBlurBoxes
    }

    private fun shouldRenderEntity(entity: LivingEntity, mc: Minecraft): Boolean {
        if (entity == mc.player) {
            return targets.value.firstOrNull { it.name.equals("Self", ignoreCase = true) }?.value == true &&
                !mc.options.cameraType.isFirstPerson
        }

        return when (entity) {
            is Player -> targets.value.firstOrNull { it.name.equals("Players", ignoreCase = true) }?.value == true
            is Animal -> targets.value.firstOrNull { it.name.equals("Animals", ignoreCase = true) }?.value == true
            is Enemy -> targets.value.firstOrNull { it.name.equals("Mobs", ignoreCase = true) }?.value == true
            else -> false
        }
    }

    private fun formatHealth(entity: LivingEntity): String {
        val hp = max(0.0f, entity.health)
        val rounded = (hp * 10.0f).roundToInt() / 10.0f
        return if (kotlin.math.abs(rounded - rounded.roundToInt()) <= 0.05f) {
            rounded.roundToInt().toString()
        } else {
            rounded.toString()
        }
    }

    private fun getHealthColor(entity: LivingEntity): Int {
        val maxHealth = max(1.0f, entity.maxHealth)
        val ratio = (entity.health / maxHealth).coerceIn(0.0f, 1.0f)
        val red = (255.0f * (1.0f - ratio)).roundToInt()
        val green = (255.0f * ratio).roundToInt()
        return (0xFF shl 24) or (red shl 16) or (green shl 8) or 0x5A
    }
}
