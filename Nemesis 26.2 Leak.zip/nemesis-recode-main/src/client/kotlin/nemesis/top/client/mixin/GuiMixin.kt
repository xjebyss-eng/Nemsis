package nemesis.top.client.mixin

import nemesis.top.client.gui.NemesisOverlay
import nemesis.top.client.gui.HudOverlay
import net.minecraft.client.DeltaTracker
import net.minecraft.client.gui.Gui
import net.minecraft.client.gui.GuiGraphicsExtractor
import org.spongepowered.asm.mixin.Mixin
import org.spongepowered.asm.mixin.injection.At
import org.spongepowered.asm.mixin.injection.Inject
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo

@Mixin(Gui::class)
class GuiMixin {
    @Inject(method = ["extractRenderState"], at = [At("HEAD")], cancellable = true)
    private fun glacierExtractClickGui(graphics: GuiGraphicsExtractor, deltaTracker: DeltaTracker, ci: CallbackInfo) {
        HudOverlay.extract(graphics)
        nemesis.top.client.module.ModuleManager.nameTags.onRenderWithEntities(graphics, deltaTracker.getGameTimeDeltaPartialTick(false))
        if (!NemesisOverlay.shouldRender()) return
        NemesisOverlay.extract(graphics)
        ci.cancel()
    }

    @Inject(method = ["extractItemHotbar"], at = [At("HEAD")], cancellable = true)
    private fun glacierCancelVanillaHotbar(graphics: GuiGraphicsExtractor, deltaTracker: DeltaTracker, ci: CallbackInfo) {
        if (HudOverlay.customHotbarActive()) ci.cancel()
    }
}
