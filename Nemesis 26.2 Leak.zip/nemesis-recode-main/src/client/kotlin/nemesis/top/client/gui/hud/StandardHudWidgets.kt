package nemesis.top.client.gui.hud

import nemesis.top.client.gui.NemesisOverlay
import nemesis.top.client.render.FontRenderer
import nemesis.top.client.render.TextureRenderer
import nemesis.top.client.util.AnimationUtil
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.GuiGraphicsExtractor
import net.minecraft.network.chat.Component
import net.minecraft.resources.Identifier
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.ceil

private const val POTION_ROW_ENTER_ANIMATION_DURATION = 260L
private const val POTION_ROW_EXIT_ANIMATION_DURATION = 320L

class WatermarkHudWidget : HudWidget(
    id = "watermark",
    title = "Watermark",
    iconGlyph = "R",
    x = 36.0f,
    y = 7.0f,
    width = 161.0f,
    height = 25.0f,
) {
    private val logo = Identifier.fromNamespaceAndPath("nemesis", "textures/gui/nemesis.png")
    private val timeFormat = DateTimeFormatter.ofPattern("HH:mm")
    private val logoBoxSize = 25.0f
    private val boxGap = 2.0f

    override fun update(mc: Minecraft, preview: Boolean) {
        val playerName = mc.player?.name?.string ?: "Player"
        val fps = "${mc.fps}fps"
        val time = LocalTime.now().format(timeFormat)
        val contentWidth = 10.0f + 13.0f + FontRenderer.width(FontRenderer.Face.SfRegular, playerName, 8.0f) +
                12.0f + 13.0f + FontRenderer.width(FontRenderer.Face.SfRegular, fps, 8.0f) +
                12.0f + 13.0f + FontRenderer.width(FontRenderer.Face.SfRegular, time, 8.0f) + 10.0f
        bounds.width = maxOf(145.0f, contentWidth)
    }

    override fun blurBoxes(guiScale: Float, tintStrength: Float): List<NemesisOverlay.BlurBox> {
        val logoX = bounds.x - logoBoxSize - boxGap
        return listOf(
            NemesisOverlay.BlurBox(
                logoX * guiScale,
                bounds.y * guiScale,
                logoBoxSize * guiScale,
                bounds.height * guiScale,
                8.0f * guiScale,
                tintStrength,
            ),
            NemesisOverlay.BlurBox(
                bounds.x * guiScale,
                bounds.y * guiScale,
                bounds.width * guiScale,
                bounds.height * guiScale,
                8.0f * guiScale,
                tintStrength,
            ),
        )
    }

    override fun render(graphics: GuiGraphicsExtractor, mc: Minecraft, preview: Boolean) {
        val playerName = mc.player?.name?.string ?: "Player"
        val fps = "${mc.fps}fps"
        val time = LocalTime.now().format(timeFormat)
        val logoX = bounds.x - logoBoxSize - boxGap
        val infoX = bounds.x
        HudStyle.panel(graphics, HudBounds(logoX, bounds.y, logoBoxSize, logoBoxSize))
        HudStyle.panel(graphics, HudBounds(infoX, bounds.y, bounds.width, bounds.height))

        val logoWidth = 18.0f
        val logoHeight = 18.0f
        HudStyle.panel(graphics, HudBounds(logoX + 3.5f, bounds.y + 3.5f, logoBoxSize - 7.0f, logoBoxSize - 7.0f), 5.0f)
        TextureRenderer.draw(
            graphics,
            logo,
            logoX + (logoBoxSize - logoWidth) * 0.5f,
            bounds.y + (logoBoxSize - logoHeight) * 0.5f,
            logoWidth,
            logoHeight,
            HudStyle.ACCENT,
        )

        var cursor = infoX + 10.0f
        
        HudStyle.icon(graphics, iconGlyph, cursor, bounds.y + 7.0f, 9.0f)
        cursor += 13.0f
        FontRenderer.draw(graphics, FontRenderer.Face.SfRegular, playerName, cursor, bounds.y + 8.0f, 8.0f, HudStyle.TEXT)
        cursor += FontRenderer.width(FontRenderer.Face.SfRegular, playerName, 8.0f) + 12.0f

        HudStyle.icon(graphics, "F", cursor, bounds.y + 7.0f, 9.0f)
        cursor += 13.0f
        FontRenderer.draw(graphics, FontRenderer.Face.SfRegular, fps, cursor, bounds.y + 8.0f, 8.0f, HudStyle.TEXT)
        cursor += FontRenderer.width(FontRenderer.Face.SfRegular, fps, 8.0f) + 12.0f

        HudStyle.icon(graphics, "G", cursor, bounds.y + 7.0f, 9.0f)
        cursor += 13.0f
        FontRenderer.draw(graphics, FontRenderer.Face.SfRegular, time, cursor, bounds.y + 8.0f, 8.0f, HudStyle.TEXT)
    }
}

class CoordinatesHudWidget : HudWidget(
    id = "coordinates",
    title = "Coordinates",
    iconGlyph = "H",
    x = 7.0f,
    y = 96.0f,
    width = 128.0f,
    height = 25.0f,
) {
    override fun update(mc: Minecraft, preview: Boolean) {
        val text = coordinates(mc)
        bounds.width = maxOf(128.0f, FontRenderer.width(FontRenderer.Face.SfRegular, text, 8.5f) + 38.0f)
    }

    override fun render(graphics: GuiGraphicsExtractor, mc: Minecraft, preview: Boolean) {
        HudStyle.panel(graphics, bounds)
        HudStyle.icon(graphics, iconGlyph, bounds.x + 9.0f, bounds.y + 7.0f, 10.0f)
        FontRenderer.draw(
            graphics,
            FontRenderer.Face.SfRegular,
            coordinates(mc),
            bounds.x + 27.0f,
            bounds.y + 8.0f,
            8.5f,
            HudStyle.TEXT,
        )
    }

    private fun coordinates(mc: Minecraft): String {
        val position = mc.player?.blockPosition() ?: return "X 0  Y 0  Z 0"
        return "X ${position.x}  Y ${position.y}  Z ${position.z}"
    }
}

class PotionsHudWidget : HudWidget(
    id = "potions",
    title = "Potions",
    iconGlyph = "B",
    x = 142.0f,
    y = 39.0f,
    width = 126.0f,
    height = 48.0f,
) {
    private val rowAnimations = linkedMapOf<String, RowState>()
    private var renderRows = emptyList<RowState>()

    override fun visible(mc: Minecraft, preview: Boolean): Boolean {
        return (enabled && effectRows(mc, false).isNotEmpty()) || preview
    }

    override fun update(mc: Minecraft, preview: Boolean) {
        renderRows = collectRows(effectRows(mc, preview))
        if (renderRows.isEmpty() && preview) {
            renderRows = listOf(previewRow("Speed 2", "1:24"), previewRow("Strength", "0:48"))
        }
        val rows = renderRows
        val animatedRows = rows.sumOf { it.animation.value.coerceAtLeast(0.0f).toDouble() }.toFloat()
        bounds.height = 31.0f + animatedRows * 17.0f
        val contentWidth = rows.maxOfOrNull {
            FontRenderer.width(FontRenderer.Face.SfRegular, it.name, 8.5f) +
                FontRenderer.width(FontRenderer.Face.SfSemibold, it.duration, 7.5f) + 38.0f
        } ?: 0.0f
        bounds.width = maxOf(126.0f, contentWidth)
    }

    override fun render(graphics: GuiGraphicsExtractor, mc: Minecraft, preview: Boolean) {
        val rows = renderRows

        HudStyle.panel(graphics, bounds)
        FontRenderer.draw(graphics, FontRenderer.Face.SfMedium, "Potions", bounds.x + 9.0f, bounds.y + 8.0f, 10.0f, HudStyle.TEXT)
        HudStyle.icon(graphics, iconGlyph, bounds.x + bounds.width - 20.0f, bounds.y + 7.0f, 10.0f)
        var rowOffset = 0.0f
        rows.forEach { row ->
            val rowProgress = row.animation.value.coerceIn(0.0f, 1.0f)
            if (rowProgress <= 0.01f) return@forEach
            val rowY = bounds.y + 29.0f + rowOffset
            val rowScale = (0.9f + minOf(rowProgress, 1.12f) * 0.1f).coerceIn(0.9f, 1.035f)
            val rowPivotX = bounds.x + bounds.width * 0.5f
            val rowPivotY = rowY + 6.5f
            val text = fadeColor(HudStyle.TEXT, rowProgress)
            val accent = fadeColor(HudStyle.ACCENT, rowProgress)

            graphics.pose().pushMatrix()
            graphics.pose().translate(rowPivotX, rowPivotY)
            graphics.pose().scale(rowScale, rowScale)
            graphics.pose().translate(-rowPivotX, -rowPivotY)
            FontRenderer.draw(graphics, FontRenderer.Face.SfRegular, row.name, bounds.x + 10.0f, rowY, 8.5f, text)
            val durationWidth = FontRenderer.width(FontRenderer.Face.SfSemibold, row.duration, 7.5f)
            FontRenderer.draw(
                graphics,
                FontRenderer.Face.SfSemibold,
                row.duration,
                bounds.x + bounds.width - durationWidth - 9.0f,
                rowY + 0.5f,
                7.5f,
                accent,
            )
            graphics.pose().popMatrix()
            rowOffset += 17.0f * rowProgress
        }
    }

    private fun effectRows(mc: Minecraft, preview: Boolean): List<EffectRow> {
        if (!enabled && !preview) return emptyList()
        val effects = mc.player?.activeEffects
            ?.sortedBy { Component.translatable(it.descriptionId).string.lowercase() }
            ?.map {
                val level = if (it.amplifier > 0) " ${it.amplifier + 1}" else ""
                EffectRow(
                    Component.translatable(it.descriptionId).string + level,
                    formatDuration(it.duration),
                )
            }
            .orEmpty()
        if (effects.isNotEmpty() || !preview) return effects
        return listOf(EffectRow("Speed 2", "1:24"), EffectRow("Strength", "0:48"))
    }

    private fun collectRows(activeRows: List<EffectRow>): List<RowState> {
        val activeRowsByKey = activeRows.associateBy { rowKey(it) }
        activeRows.forEach { row ->
            val state = rowAnimations.computeIfAbsent(rowKey(row)) { RowState(row.name, row.duration) }
            state.name = row.name
            state.duration = row.duration
        }

        val rows = mutableListOf<RowState>()
        val iterator = rowAnimations.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            val row = entry.value
            val active = activeRowsByKey.containsKey(entry.key)
            row.animation.update()
            row.animation.run(if (active) 1.0f else 0.0f,
                if (active) POTION_ROW_ENTER_ANIMATION_DURATION else POTION_ROW_EXIT_ANIMATION_DURATION,
                if (active) AnimationUtil::easeOutSoftBack else AnimationUtil::easeInBack,
                true,
            )
            if (!active && row.animation.value <= 0.01f) iterator.remove()
            else rows += row
        }

        return rows.sortedBy { row ->
            activeRows.indexOfFirst { rowKey(it) == rowKey(row.name) }.let {
                if (it < 0) Int.MAX_VALUE else it
            }
        }
    }

    private fun previewRow(name: String, duration: String): RowState {
        return RowState(name, duration).also { it.animation.snap(1.0f) }
    }

    private fun rowKey(row: EffectRow): String {
        return rowKey(row.name)
    }

    private fun rowKey(name: String): String {
        return name
    }

    private fun formatDuration(ticks: Int): String {
        if (ticks < 0) return "∞"
        val seconds = ceil(ticks / 20.0).toInt()
        return "${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}"
    }

    private data class EffectRow(val name: String, val duration: String)

    private class RowState(
        var name: String,
        var duration: String,
    ) {
        val animation = AnimationUtil.TimedAnimation(0.0f)
    }

    private fun fadeColor(color: Int, alphaMultiplier: Float): Int {
        val alpha = ((color ushr 24) * alphaMultiplier.coerceIn(0.0f, 1.0f)).toInt().coerceIn(0, 255)
        return (color and 0x00FFFFFF) or (alpha shl 24)
    }
}

class InventoryHudWidget : HudWidget(
    id = "inventory",
    title = "Inventory",
    iconGlyph = "L",
    x = 142.0f,
    y = 96.0f,
    width = 164.0f,
    height = 56.0f,
    enabledByDefault = false,
) {
    override fun render(graphics: GuiGraphicsExtractor, mc: Minecraft, preview: Boolean) {
        val player = mc.player ?: return
        HudStyle.panel(graphics, bounds)
        val slotSize = 18.0f
        for (index in 0 until 27) {
            val column = index % 9
            val row = index / 9
            val slotX = bounds.x + 1.0f + column * slotSize
            val slotY = bounds.y + 1.0f + row * slotSize
            HudStyle.rect(graphics, slotX, slotY, 17.0f, 17.0f, 2.0f, 0x12000000)
            val stack = player.inventory.getItem(index + 9)
            if (!stack.isEmpty) {
                graphics.item(stack, slotX.toInt(), slotY.toInt())
                graphics.itemDecorations(mc.font, stack, slotX.toInt(), slotY.toInt())
            }
        }
    }
}

class HotbarHudWidget : HudWidget(
    id = "hotbar",
    title = "Hotbar",
    iconGlyph = "H",
    x = Float.NaN,
    y = Float.NaN,
    width = 184.0f,
    height = 24.0f,
    enabledByDefault = false,
    movable = false,
) {
    private var animatedSelectedSlot = -1.0f

    override fun render(graphics: GuiGraphicsExtractor, mc: Minecraft, preview: Boolean) {
        val player = mc.player ?: return
        HudStyle.panel(graphics, bounds)
        val selected = player.inventory.selectedSlot
        if (animatedSelectedSlot < 0.0f) {
            animatedSelectedSlot = selected.toFloat()
        } else {
            animatedSelectedSlot += (selected - animatedSelectedSlot) * 0.28f
        }
        val selectedSlotX = bounds.x + 2.0f + animatedSelectedSlot * 20.0f
        HudStyle.rect(graphics, selectedSlotX, bounds.y + 2.0f, 20.0f, 20.0f, 5.0f, 0x5988FF82)
        for (slot in 0 until 9) {
            val slotX = bounds.x + 2.0f + slot * 20.0f
            val stack = player.inventory.getItem(slot)
            if (!stack.isEmpty) {
                graphics.item(stack, (slotX + 2.0f).toInt(), (bounds.y + 4.0f).toInt())
                graphics.itemDecorations(mc.font, stack, (slotX + 2.0f).toInt(), (bounds.y + 4.0f).toInt())
            }
        }
    }
}
