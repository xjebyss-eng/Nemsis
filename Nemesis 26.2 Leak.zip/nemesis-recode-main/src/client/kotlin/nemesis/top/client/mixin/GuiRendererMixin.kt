package nemesis.top.client.mixin

import com.mojang.blaze3d.buffers.GpuBufferSlice
import nemesis.top.client.render.DoubleKawaseBlurRenderer
import net.minecraft.client.gui.render.GuiRenderer
import org.spongepowered.asm.mixin.Mixin
import org.spongepowered.asm.mixin.injection.At
import org.spongepowered.asm.mixin.injection.Inject
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo

@Mixin(GuiRenderer::class)
class GuiRendererMixin {
    @Inject(method = ["render"], at = [At("HEAD")])
    private fun glacierRenderDoubleKawaseBlur(gpuBufferSlice: GpuBufferSlice, ci: CallbackInfo) {
        DoubleKawaseBlurRenderer.renderIfVisible()
    }
}
