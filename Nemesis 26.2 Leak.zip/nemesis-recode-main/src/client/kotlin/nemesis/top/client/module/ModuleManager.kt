package nemesis.top.client.module

import nemesis.top.client.module.modules.combat.BacktrackModule
import nemesis.top.client.module.modules.combat.AutoTrapModule
import nemesis.top.client.module.modules.combat.KillauraModule
import nemesis.top.client.module.modules.movement.AntiWebModule
import nemesis.top.client.module.modules.movement.MoveFixModule
import nemesis.top.client.module.modules.movement.SpearLungeModule
import nemesis.top.client.module.modules.movement.SpeedModule
import nemesis.top.client.module.modules.movement.SprintModule
import nemesis.top.client.module.modules.movement.WindHopModule
import nemesis.top.client.module.modules.player.FakePlayerModule
import nemesis.top.client.module.modules.player.FakeLagModule
import nemesis.top.client.module.modules.visual.BlockOverlayModule
import nemesis.top.client.module.modules.visual.HandShaderModule
import nemesis.top.client.module.modules.visual.ChamsModule
import nemesis.top.client.module.modules.visual.NameTagsModule
import nemesis.top.client.module.modules.visual.LiquidFogModule
import nemesis.top.client.module.modules.visual.PostProcessingModule
import nemesis.top.client.module.modules.visual.RotationViewModule
import nemesis.top.client.module.modules.visual.TargetEspModule
import nemesis.top.client.module.modules.visual.ViewModelModule

object ModuleManager {
    val postProcessing = PostProcessingModule()
    val liquidFog = LiquidFogModule()
    val targetEsp = TargetEspModule()
    val rotationView = RotationViewModule()
    val nameTags = NameTagsModule()
    val killaura = KillauraModule()
    val autoTrap = AutoTrapModule()
    val backtrack = BacktrackModule()
    val moveFix = MoveFixModule()
    val antiWeb = AntiWebModule()
    val spearLunge = SpearLungeModule()
    val speed = SpeedModule()
    val sprint = SprintModule()
    val windHop = WindHopModule()
    val fakePlayer = FakePlayerModule()
    val fakeLag = FakeLagModule()
    val blockOverlay = BlockOverlayModule()
    val handShader = HandShaderModule()
    val chams = ChamsModule()
    val viewModel = ViewModelModule()

    val modules: List<Module> = listOf(
        killaura,
        autoTrap,
        backtrack,
        moveFix,
        antiWeb,
        spearLunge,
        speed,
        sprint,
        windHop,
        fakePlayer,
        fakeLag,
        rotationView,
        postProcessing,
        liquidFog,
        targetEsp,
        nameTags,
        blockOverlay,
        handShader,
        viewModel,
        chams,
    )

    fun modulesIn(category: ModuleCategory): List<Module> {
        return modules.filter { it.category == category }
    }

    fun handleKey(key: Int): Boolean {
        var handled = false
        modules.forEach { module ->
            if (module.bind == key) {
                if (module.onBindPressed()) {
                    handled = true
                }
            }
        }
        return handled
    }
}
