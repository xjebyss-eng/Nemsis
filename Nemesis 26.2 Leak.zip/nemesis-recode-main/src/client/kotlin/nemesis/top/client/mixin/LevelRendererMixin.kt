package nemesis.top.client.mixin

import com.mojang.blaze3d.buffers.GpuBufferSlice
import com.mojang.blaze3d.resource.GraphicsResourceAllocator
import nemesis.top.client.util.ProjectionUtil
import net.minecraft.client.DeltaTracker
import net.minecraft.client.renderer.LevelRenderer
import net.minecraft.client.renderer.chunk.ChunkSectionsToRender
import net.minecraft.client.renderer.state.level.CameraRenderState
import org.joml.Matrix4fc
import org.joml.Vector4f
import org.spongepowered.asm.mixin.Mixin
import org.spongepowered.asm.mixin.injection.At
import org.spongepowered.asm.mixin.injection.Inject
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo

@Mixin(LevelRenderer::class)
class LevelRendererMixin {
    @Suppress("UNUSED_PARAMETER")
    @Inject(
        method = ["renderLevel"],
        at = [At("HEAD")],
    )
    private fun glacierCaptureProjectionState(
        allocator: GraphicsResourceAllocator,
        deltaTracker: DeltaTracker,
        renderBlockOutline: Boolean,
        cameraRenderState: CameraRenderState,
        projectionMatrix: Matrix4fc,
        colorSlice: GpuBufferSlice,
        fogColor: Vector4f,
        renderSky: Boolean,
        chunkSectionsToRender: ChunkSectionsToRender,
        ci: CallbackInfo,
    ) {
        ProjectionUtil.capture(cameraRenderState, projectionMatrix)
    }
}
