package nemesis.top.client.util

import com.mojang.blaze3d.pipeline.RenderPipeline
import com.mojang.blaze3d.vertex.VertexConsumer
import nemesis.top.client.math.RoundingRule
import nemesis.top.client.render.RoundingType
import net.minecraft.client.gui.GuiGraphicsExtractor
import net.minecraft.client.gui.navigation.ScreenRectangle
import net.minecraft.client.gui.render.TextureSetup
import net.minecraft.client.renderer.RenderPipelines
import net.minecraft.client.renderer.state.gui.GuiElementRenderState
import net.minecraft.resources.Identifier
import org.joml.Matrix3x2f
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

object GuiShapeUtil {
    private val roundedRectPipeline: RenderPipeline = RenderPipelines.register(
        RenderPipeline.builder(RenderPipelines.GUI_TEXTURED_SNIPPET)
            .withLocation(Identifier.fromNamespaceAndPath("nemesis", "pipeline/rounded_rect"))
            .withFragmentShader(Identifier.fromNamespaceAndPath("nemesis", "core/rounded_rect"))
            .build()
    )
    private val roundedRectSquirclePipeline: RenderPipeline = RenderPipelines.register(
        RenderPipeline.builder(RenderPipelines.GUI_TEXTURED_SNIPPET)
            .withLocation(Identifier.fromNamespaceAndPath("nemesis", "pipeline/rounded_rect_squircle"))
            .withFragmentShader(Identifier.fromNamespaceAndPath("nemesis", "core/rounded_rect_squircle"))
            .build()
    )
    private val circlePipeline: RenderPipeline = RenderPipelines.register(
        RenderPipeline.builder(RenderPipelines.GUI_TEXTURED_SNIPPET)
            .withLocation(Identifier.fromNamespaceAndPath("nemesis", "pipeline/circle"))
            .withFragmentShader(Identifier.fromNamespaceAndPath("nemesis", "core/circle"))
            .build()
    )
    private val roundedOutlinePipeline: RenderPipeline = RenderPipelines.register(
        RenderPipeline.builder(RenderPipelines.GUI_TEXTURED_SNIPPET)
            .withLocation(Identifier.fromNamespaceAndPath("nemesis", "pipeline/rounded_outline"))
            .withFragmentShader(Identifier.fromNamespaceAndPath("nemesis", "core/rounded_outline"))
            .build()
    )

    fun roundedFill(
        graphics: GuiGraphicsExtractor,
        left: Int,
        top: Int,
        right: Int,
        bottom: Int,
        radius: Int,
        color: Int,
        roundingRule: RoundingRule = RoundingUtil.ROUNDING_RULE,
    ) {
        roundedFill(graphics, left.toFloat(), top.toFloat(), right.toFloat(), bottom.toFloat(), radius.toFloat(), color, roundingRule)
    }

    fun roundedFill(
        graphics: GuiGraphicsExtractor,
        left: Float,
        top: Float,
        right: Float,
        bottom: Float,
        radius: Float,
        color: Int,
        roundingRule: RoundingRule = RoundingUtil.ROUNDING_RULE,
    ) {
        if (((color ushr 24) and 0xFF) <= 0) return

        val x0 = min(left, right)
        val y0 = min(top, bottom)
        val x1 = max(left, right)
        val y1 = max(top, bottom)
        val width = x1 - x0
        val height = y1 - y0
        if (width <= 0.05f || height <= 0.05f) return

        val resolvedRadius = RoundedRectangleGeometry.stableRadius(width, height, radius)
        graphics.guiRenderState.addGuiElement(
            ShaderRoundedRectState(
                roundedRectPipeline,
                Matrix3x2f(graphics.pose()),
                x0,
                y0,
                x1,
                y1,
                resolvedRadius,
                color,
                RoundedRectangleGeometry.antiAliasWidth(width, height),
                graphics.scissorStack.peek(),
            )
        )
    }

    fun circleFill(
        graphics: GuiGraphicsExtractor,
        centerX: Float,
        centerY: Float,
        radius: Float,
        color: Int,
    ) {
        if (((color ushr 24) and 0xFF) <= 0 || radius <= 0.05f) return

        val x0 = centerX - radius
        val y0 = centerY - radius
        val x1 = centerX + radius
        val y1 = centerY + radius
        graphics.guiRenderState.addGuiElement(
            ShaderCircleState(
                circlePipeline,
                Matrix3x2f(graphics.pose()),
                x0,
                y0,
                x1,
                y1,
                color,
                RoundedRectangleGeometry.antiAliasWidth(radius * 2.0f, radius * 2.0f),
                graphics.scissorStack.peek(),
            )
        )
    }

    fun roundedStroke(
        graphics: GuiGraphicsExtractor,
        left: Float,
        top: Float,
        right: Float,
        bottom: Float,
        radius: Float,
        color: Int,
    ) {
        if (((color ushr 24) and 0xFF) <= 0) return

        val x0 = min(left, right)
        val y0 = min(top, bottom)
        val x1 = max(left, right)
        val y1 = max(top, bottom)
        val width = x1 - x0
        val height = y1 - y0
        if (width <= 0.05f || height <= 0.05f) return

        val resolvedRadius = RoundedRectangleGeometry.stableRadius(width, height, radius)
        graphics.guiRenderState.addGuiElement(
            ShaderRoundedRectState(
                roundedOutlinePipeline,
                Matrix3x2f(graphics.pose()),
                x0,
                y0,
                x1,
                y1,
                resolvedRadius,
                color,
                RoundedRectangleGeometry.antiAliasWidth(width, height),
                graphics.scissorStack.peek(),
            )
        )
    }

    private data class ShaderRoundedRectState(
        private val pipeline: RenderPipeline,
        private val pose: Matrix3x2f,
        private val left: Float,
        private val top: Float,
        private val right: Float,
        private val bottom: Float,
        private val radius: Float,
        private val color: Int,
        private val antiAliasWidth: Float,
        private val scissorArea: ScreenRectangle?,
    ) : GuiElementRenderState {
        override fun buildVertices(consumer: VertexConsumer) {
            val encodedRadius = floor(radius.coerceAtLeast(0.0f) * 256.0f + 0.5f)
            consumer.addVertexWith2DPose(pose, left, top).setUv(0.0f, encodedRadius).setColor(color)
            consumer.addVertexWith2DPose(pose, left, bottom).setUv(0.0f, encodedRadius + 1.0f).setColor(color)
            consumer.addVertexWith2DPose(pose, right, bottom).setUv(1.0f, encodedRadius + 1.0f).setColor(color)
            consumer.addVertexWith2DPose(pose, right, top).setUv(1.0f, encodedRadius).setColor(color)
        }

        override fun pipeline(): RenderPipeline = pipeline

        override fun textureSetup(): TextureSetup = TextureSetup.noTexture()

        override fun scissorArea(): ScreenRectangle? = scissorArea

        override fun bounds(): ScreenRectangle {
            val aa = antiAliasWidth + 1.0f
            val x = floor(left - aa).toInt()
            val y = floor(top - aa).toInt()
            val width = max(1, ceil((right - left) + aa * 2.0f).toInt())
            val height = max(1, ceil((bottom - top) + aa * 2.0f).toInt())
            return ScreenRectangle(x, y, width, height)
        }
    }

    private data class ShaderCircleState(
        private val pipeline: RenderPipeline,
        private val pose: Matrix3x2f,
        private val left: Float,
        private val top: Float,
        private val right: Float,
        private val bottom: Float,
        private val color: Int,
        private val antiAliasWidth: Float,
        private val scissorArea: ScreenRectangle?,
    ) : GuiElementRenderState {
        override fun buildVertices(consumer: VertexConsumer) {
            consumer.addVertexWith2DPose(pose, left, top).setUv(0.0f, 0.0f).setColor(color)
            consumer.addVertexWith2DPose(pose, left, bottom).setUv(0.0f, 1.0f).setColor(color)
            consumer.addVertexWith2DPose(pose, right, bottom).setUv(1.0f, 1.0f).setColor(color)
            consumer.addVertexWith2DPose(pose, right, top).setUv(1.0f, 0.0f).setColor(color)
        }

        override fun pipeline(): RenderPipeline = pipeline

        override fun textureSetup(): TextureSetup = TextureSetup.noTexture()

        override fun scissorArea(): ScreenRectangle? = scissorArea

        override fun bounds(): ScreenRectangle {
            val aa = antiAliasWidth + 1.0f
            val x = floor(left - aa).toInt()
            val y = floor(top - aa).toInt()
            val width = max(1, ceil((right - left) + aa * 2.0f).toInt())
            val height = max(1, ceil((bottom - top) + aa * 2.0f).toInt())
            return ScreenRectangle(x, y, width, height)
        }
    }
}
