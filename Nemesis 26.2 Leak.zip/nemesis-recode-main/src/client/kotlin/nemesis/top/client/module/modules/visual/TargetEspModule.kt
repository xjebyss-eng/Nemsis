package nemesis.top.client.module.modules.visual

import com.mojang.blaze3d.buffers.GpuBuffer
import com.mojang.blaze3d.pipeline.BlendFunction
import com.mojang.blaze3d.pipeline.ColorTargetState
import com.mojang.blaze3d.pipeline.DepthStencilState
import com.mojang.blaze3d.pipeline.RenderPipeline
import com.mojang.blaze3d.platform.CompareOp
import com.mojang.blaze3d.systems.RenderSystem
import com.mojang.blaze3d.vertex.DefaultVertexFormat
import com.mojang.blaze3d.vertex.PoseStack
import com.mojang.blaze3d.vertex.Tesselator
import com.mojang.blaze3d.vertex.VertexFormat
import nemesis.top.client.module.Module
import nemesis.top.client.module.ModuleCategory
import nemesis.top.client.module.ModuleManager
import nemesis.top.client.module.setting.BooleanSetting
import nemesis.top.client.module.setting.EnumSetting
import nemesis.top.client.module.setting.FloatSetting
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext
import net.minecraft.client.Minecraft
import net.minecraft.client.renderer.RenderPipelines
import net.minecraft.resources.Identifier
import net.minecraft.util.Mth
import net.minecraft.world.entity.Entity
import net.minecraft.world.phys.Vec3
import org.joml.Matrix4f
import org.joml.Vector3f
import org.joml.Vector4f
import java.util.OptionalDouble
import java.util.OptionalInt
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin

class TargetEspModule : Module(
    name = "Target ESP",
    category = ModuleCategory.VISUALS,
    description = "Renders shadered ghost trails around the current combat target.",
    enabledByDefault = false,
) {
    enum class Mode(val label: String) {
        GHOSTS("Ghosts"),
    }

    enum class GhostPathMode(val label: String) {
        DEFAULT("Default"),
        TRIANGLE("Triangle"),
        COLUMN("Column"),
        SPIRAL("Spiral"),
        DOUBLE_HELIX("Double Helix"),
        TRIPLE_HELIX("Triple Helix"),
    }

    private val mode = setting(EnumSetting("Mode", Mode.entries.toTypedArray(), Mode.GHOSTS) { it.label })
    private val ghostPathMode = setting(EnumSetting("Path Mode", GhostPathMode.entries.toTypedArray(), GhostPathMode.DOUBLE_HELIX) { it.label }.visibleWhen { mode.value == Mode.GHOSTS })
    private val ghostStaticTrail = setting(BooleanSetting("Ghost Trail", false).visibleWhen { mode.value == Mode.GHOSTS })
    private val ghostTrailLength = setting(FloatSetting("Trail Length", 3.0f, 1.0f, 12.0f, 0.25f).visibleWhen { mode.value == Mode.GHOSTS })
    private val ghostRotationSpeed = setting(FloatSetting("Rotation Speed", 8.0f, 1.0f, 18.0f, 0.25f).visibleWhen { mode.value == Mode.GHOSTS })
    private val ghostRadius = setting(FloatSetting("Radius", 0.82f, 0.35f, 1.45f, 0.025f).visibleWhen { mode.value == Mode.GHOSTS })
    private val ghostHeadSize = setting(FloatSetting("Head Size", 0.095f, 0.035f, 0.22f, 0.005f).visibleWhen { mode.value == Mode.GHOSTS })
    private val ghostTrailSize = setting(FloatSetting("Trail Size", 0.055f, 0.02f, 0.14f, 0.005f).visibleWhen { mode.value == Mode.GHOSTS })
    private val renderModelView = Matrix4f()
    private val dynamicColor = Vector4f(1.0f, 1.0f, 1.0f, 1.0f)
    private val modelOffset = Vector3f()
    private val textureMatrix = Matrix4f()

    fun renderGizmos(context: LevelRenderContext) {
        val mc = Minecraft.getInstance()
        if (!enabled || mc.level == null || mc.player == null) return
        val target = ModuleManager.killaura.target ?: ModuleManager.backtrack.target ?: return
        if (!target.isAlive) return

        val now = System.currentTimeMillis()
        val poseStack = context.poseStack()
        renderModelView.set(context.levelState().cameraRenderState.viewRotationMatrix)
        renderGhostPaths(target, now, poseStack, mc.gameRenderer.mainCamera.position())
    }

    private fun renderGhostPaths(target: Entity, now: Long, poseStack: PoseStack, cameraPos: Vec3) {
        val center = targetCenter(target).subtract(cameraPos)
        val radius = ghostRadius.value.toDouble()
        val speed = max(0.1f, 60.0f - ghostRotationSpeed.value)
        val spacing = 4.8f
        val trailLen = max(1, (ghostTrailLength.value * 4.0f).toInt())
        val elapsedTime = now.toDouble()
        val ghostCount = when (ghostPathMode.value) {
            GhostPathMode.DOUBLE_HELIX -> 2
            GhostPathMode.SPIRAL -> 4
            else -> 3
        }
        val billboards = ArrayList<Billboard>(trailLen * ghostCount)

        for (ghostIndex in 0 until ghostCount) {
            appendGhostPath(billboards, ghostPathMode.value, ghostIndex, center, target.bbHeight.toDouble(), radius, speed, spacing, trailLen, elapsedTime)
        }

        renderTexturedBillboards(billboards, poseStack, ghostPipeline, additive = false)
    }

    private fun appendGhostPath(
        billboards: MutableList<Billboard>,
        pathMode: GhostPathMode,
        ghostIndex: Int,
        center: Vec3,
        targetHeight: Double,
        radius: Double,
        speed: Float,
        spacing: Float,
        trailLen: Int,
        elapsedTime: Double,
    ) {
        for (i in 0 until trailLen) {
            val sampleTime = elapsedTime - i * spacing
            val timeOffset = 0.15 * sampleTime / speed
            val ghostPoint = when (pathMode) {
                GhostPathMode.DEFAULT -> {
                    val rotation = 0.045 * sampleTime / speed
                    val verticalRotation = 0.035 * sampleTime / speed
                    val angle = timeOffset + rotation + ghostIndex * 2.0
                    center.add(cos(angle) * radius, sin(angle + verticalRotation) * radius * 0.78, sin(angle) * radius)
                }
                GhostPathMode.TRIANGLE -> {
                    val xOffset = cos(timeOffset) * radius
                    val zOffset = sin(timeOffset) * radius
                    when {
                        ghostIndex == 0 -> center.add(xOffset, zOffset, -zOffset)
                        ghostIndex == 1 -> center.add(-xOffset, xOffset, -zOffset)
                        else -> center.add(-xOffset, -xOffset, zOffset)
                    }
                }
                GhostPathMode.COLUMN -> {
                    val phase = timeOffset + ghostIndex * (Math.PI * 2.0 / 3.0)
                    val heightOffsets = doubleArrayOf(targetHeight * 0.5, 0.0, -targetHeight * 0.5)
                    center.add(cos(phase) * radius, heightOffsets[ghostIndex.coerceIn(0, 2)], sin(phase) * radius)
                }
                GhostPathMode.SPIRAL -> {
                    val phase = timeOffset + ghostIndex * (Math.PI * 2.0 / 4.0)
                    center.add(cos(phase) * radius, sin(timeOffset * 0.75) * targetHeight * 0.5, sin(phase) * radius)
                }
                GhostPathMode.DOUBLE_HELIX -> {
                    val phase = timeOffset + if (ghostIndex == 0) 0.0 else Math.PI
                    center.add(cos(phase) * radius, sin(phase * 0.5) * radius, sin(phase) * radius)
                }
                GhostPathMode.TRIPLE_HELIX -> {
                    val phase = timeOffset + ghostIndex * (Math.PI * 2.0 / 3.0)
                    center.add(cos(phase) * radius, sin(phase * 0.5) * radius, sin(phase) * radius)
                }
            }
            val progress = i.toFloat() / trailLen.toFloat()
            val smoothProgress = 1.0f - (1.0f - progress).pow(3.0f)
            val trailFade = (1.0f - progress).pow(2.2f)
            val size = lerp(ghostHeadSize.value, ghostTrailSize.value, smoothProgress)
            val alphaScale = if (ghostStaticTrail.value) 1.0f else trailFade
            val alpha = Mth.clamp((210.0f * alphaScale).toInt(), 0, 210)
            if (alpha > 4) {
                billboards += Billboard(ghostPoint, size, themeGradient((timeOffset * 100.0).toInt(), alpha))
            }
        }
    }

    private fun renderTexturedBillboards(billboards: List<Billboard>, poseStack: PoseStack, pipeline: RenderPipeline, additive: Boolean) {
        if (billboards.isEmpty()) return
        val mc = Minecraft.getInstance()
        val camera = mc.gameRenderer.mainCamera
        val builder = Tesselator.getInstance().begin(VertexFormat.Mode.TRIANGLES, DefaultVertexFormat.POSITION_TEX_COLOR)

        for (billboard in billboards) {
            val pose = PoseStack()
            pose.translate(billboard.center.x, billboard.center.y, billboard.center.z)
            pose.mulPose(camera.rotation())
            appendBillboard(builder, pose.last(), billboard.halfSize, billboard.color)
        }

        builder.build()?.use { mesh ->
            val vertexBuffer = RenderSystem.getDevice().createBuffer({ "Nemesis TargetESP ghosts" }, GpuBuffer.USAGE_VERTEX, mesh.vertexBuffer())
            try {
                val mainTarget = mc.mainRenderTarget
                val colorView = RenderSystem.outputColorTextureOverride ?: mainTarget.colorTextureView ?: return
                val depthView = RenderSystem.outputDepthTextureOverride ?: mainTarget.depthTextureView
                val dynamicTransforms = RenderSystem.getDynamicUniforms().writeTransform(
                    renderModelView,
                    dynamicColor,
                    modelOffset,
                    textureMatrix,
                )
                val encoder = RenderSystem.getDevice().createCommandEncoder()
                val pass = if (depthView != null) {
                    encoder.createRenderPass(
                        { "Nemesis TargetESP ghosts" },
                        colorView,
                        OptionalInt.empty(),
                        depthView,
                        OptionalDouble.empty(),
                    )
                } else {
                    encoder.createRenderPass(
                        { "Nemesis TargetESP ghosts" },
                        colorView,
                        OptionalInt.empty(),
                    )
                }
                pass.use {
                    it.setPipeline(pipeline)
                    RenderSystem.bindDefaultUniforms(it)
                    it.setUniform("DynamicTransforms", dynamicTransforms)
                    it.setVertexBuffer(0, vertexBuffer)
                    it.draw(0, mesh.drawState().vertexCount())
                }
            } finally {
                vertexBuffer.close()
            }
        }
    }

    private fun appendBillboard(
        builder: com.mojang.blaze3d.vertex.BufferBuilder,
        pose: PoseStack.Pose,
        halfSize: Float,
        color: Int,
    ) {
        vertex(builder, pose, -halfSize, halfSize, 0.0f, 0.0f, 1.0f, color)
        vertex(builder, pose, halfSize, halfSize, 0.0f, 1.0f, 1.0f, color)
        vertex(builder, pose, halfSize, -halfSize, 0.0f, 1.0f, 0.0f, color)
        vertex(builder, pose, -halfSize, halfSize, 0.0f, 0.0f, 1.0f, color)
        vertex(builder, pose, halfSize, -halfSize, 0.0f, 1.0f, 0.0f, color)
        vertex(builder, pose, -halfSize, -halfSize, 0.0f, 0.0f, 0.0f, color)
    }

    private fun vertex(
        builder: com.mojang.blaze3d.vertex.BufferBuilder,
        pose: PoseStack.Pose,
        x: Float,
        y: Float,
        z: Float,
        u: Float,
        v: Float,
        color: Int,
    ) {
        builder.addVertex(pose, x, y, z).setUv(u, v).setColor(color)
    }

    private fun targetCenter(target: Entity): Vec3 {
        val tickDelta = Minecraft.getInstance().deltaTracker.getGameTimeDeltaPartialTick(false)
        return Vec3(
            target.xOld + (target.x - target.xOld) * tickDelta,
            target.yOld + (target.y - target.yOld) * tickDelta + target.bbHeight * 0.5,
            target.zOld + (target.z - target.zOld) * tickDelta,
        )
    }

    private fun themeGradient(index: Int, alpha: Int): Int {
        val phase = Math.toRadians((index % 360).toDouble())
        val primary = rgba(0x88, 0xFF, 0x82, alpha)
        val secondary = rgba(0x21, 0x8F, 0xFF, alpha)
        val t = (0.5 + 0.5 * sin(phase)).toFloat()
        return blendColors(primary, secondary, t)
    }

    private fun blendColors(startColor: Int, endColor: Int, progress: Float): Int {
        val p = progress.coerceIn(0.0f, 1.0f)
        val sa = (startColor ushr 24) and 0xFF
        val sr = (startColor ushr 16) and 0xFF
        val sg = (startColor ushr 8) and 0xFF
        val sb = startColor and 0xFF
        val ea = (endColor ushr 24) and 0xFF
        val er = (endColor ushr 16) and 0xFF
        val eg = (endColor ushr 8) and 0xFF
        val eb = endColor and 0xFF
        return rgba(
            (sr + (er - sr) * p).toInt(),
            (sg + (eg - sg) * p).toInt(),
            (sb + (eb - sb) * p).toInt(),
            (sa + (ea - sa) * p).toInt(),
        )
    }

    private fun rgba(red: Int, green: Int, blue: Int, alpha: Int): Int {
        return ((alpha.coerceIn(0, 255) and 0xFF) shl 24) or
            ((red.coerceIn(0, 255) and 0xFF) shl 16) or
            ((green.coerceIn(0, 255) and 0xFF) shl 8) or
            (blue.coerceIn(0, 255) and 0xFF)
    }

    private fun lerp(from: Float, to: Float, progress: Float): Float {
        return from + (to - from) * progress.coerceIn(0.0f, 1.0f)
    }

    private data class Billboard(val center: Vec3, val halfSize: Float, val color: Int)

    companion object {
        private val ghostPipeline: RenderPipeline = RenderPipelines.register(
            RenderPipeline.builder(RenderPipelines.MATRICES_FOG_SNIPPET)
                .withLocation(Identifier.fromNamespaceAndPath("nemesis", "pipeline/target_esp_ghosts"))
                .withVertexShader(Identifier.withDefaultNamespace("core/position_tex_color"))
                .withFragmentShader(Identifier.fromNamespaceAndPath("nemesis", "core/target_ghost"))
                .withVertexFormat(DefaultVertexFormat.POSITION_TEX_COLOR, VertexFormat.Mode.TRIANGLES)
                .withCull(false)
                .withColorTargetState(ColorTargetState(BlendFunction.ADDITIVE))
                .withDepthStencilState(DepthStencilState(CompareOp.LESS_THAN_OR_EQUAL, false))
                .build()
        )
    }
}
