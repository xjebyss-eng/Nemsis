package nemesis.top.client.mixin

import nemesis.top.client.gui.NemesisOverlay
import nemesis.top.client.gui.HudOverlay
import nemesis.top.client.module.ModuleManager
import net.minecraft.client.Minecraft
import net.minecraft.client.KeyboardHandler
import net.minecraft.client.input.KeyEvent
import org.lwjgl.glfw.GLFW
import org.spongepowered.asm.mixin.Mixin
import org.spongepowered.asm.mixin.injection.At
import org.spongepowered.asm.mixin.injection.Inject
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo

@Mixin(KeyboardHandler::class)
class KeyboardHandlerMixin {
    @Inject(method = ["keyPress"], at = [At("HEAD")], cancellable = true)
    private fun glacierOnKey(window: Long, action: Int, event: KeyEvent, ci: CallbackInfo) {
        val mc = Minecraft.getInstance()
        if (action == GLFW.GLFW_PRESS && mc.screen == null && event.key() == GLFW.GLFW_KEY_INSERT && HudOverlay.toggleEditor()) {
            ci.cancel()
            return
        }
        if (action == GLFW.GLFW_PRESS && event.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            if (mc.screen == null || NemesisOverlay.visible) {
                NemesisOverlay.toggle()
                ci.cancel()
                return
            }
        }

        if (NemesisOverlay.keyPressed(event.key(), action)) {
            ci.cancel()
            return
        }

        if (action == GLFW.GLFW_PRESS && mc.screen == null && ModuleManager.handleKey(event.key())) {
            ci.cancel()
        }
    }
}
