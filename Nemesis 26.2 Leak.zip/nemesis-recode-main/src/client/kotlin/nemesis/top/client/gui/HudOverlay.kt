package nemesis.top.client.gui

import nemesis.top.client.gui.hud.HudManager
import net.minecraft.client.gui.GuiGraphicsExtractor

object HudOverlay {
    fun extract(graphics: GuiGraphicsExtractor) = HudManager.extract(graphics)

    fun shouldPostProcess(): Boolean = HudManager.shouldPostProcess()

    fun customHotbarActive(): Boolean = HudManager.customHotbarActive()

    fun blurBoxes(guiScale: Float): List<NemesisOverlay.BlurBox> = HudManager.blurBoxes(guiScale)

    fun toggleEditor(): Boolean = HudManager.toggleEditor()

    fun mouseClicked(button: Int, action: Int): Boolean = HudManager.mouseClicked(button, action)

    fun mouseReleased(action: Int): Boolean = HudManager.mouseReleased(action)
}
