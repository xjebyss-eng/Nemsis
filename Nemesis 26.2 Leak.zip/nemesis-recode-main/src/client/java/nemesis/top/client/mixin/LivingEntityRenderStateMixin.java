package nemesis.top.client.mixin;

import nemesis.top.client.render.ChamsRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(LivingEntityRenderState.class)
public class LivingEntityRenderStateMixin implements ChamsRenderState {
    private boolean nemesis$isSelf;
    private boolean nemesis$isPlayer;
    private boolean nemesis$isMob;
    private boolean nemesis$isAnimal;

    @Override
    public boolean isSelf() {
        return nemesis$isSelf;
    }

    @Override
    public void setSelf(boolean val) {
        this.nemesis$isSelf = val;
    }

    @Override
    public boolean isPlayer() {
        return nemesis$isPlayer;
    }

    @Override
    public void setPlayer(boolean val) {
        this.nemesis$isPlayer = val;
    }

    @Override
    public boolean isMob() {
        return nemesis$isMob;
    }

    @Override
    public void setMob(boolean val) {
        this.nemesis$isMob = val;
    }

    @Override
    public boolean isAnimal() {
        return nemesis$isAnimal;
    }

    @Override
    public void setAnimal(boolean val) {
        this.nemesis$isAnimal = val;
    }
}
